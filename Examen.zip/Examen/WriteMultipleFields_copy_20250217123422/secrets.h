// Use this file to store all of the private credentials 
// and connection details

#define SECRET_SSID "UAM-ROBOTICA"		// replace MySSID with your WiFi network name
#define SECRET_PASS "m4nt32024uat"	// replace MyPassword with your WiFi password

#define SECRET_CH_ID 2823836			// replace 0000000 with your channel number
#define SECRET_WRITE_APIKEY "4I2FZ3IHDSNFJP8O"   // replace XYZ with your channel write API Key